V32CAP3 数据帧 —— FPGA 发送端交接包
=====================================

先读这个，再动手：
  V32CAP3_FPGA_TX_SPEC.md          规格书（第 0 节有可直接给 AI 的提示词）

参考实现：
  rtl/v32cap3_tx.v                 组帧状态机（CRC 模式）
  rtl/uart_tx.v                    8N1 发送器，分频四舍五入
  references/raw_snapshot_uart.v   厂商原始 RTL（真实归档用的就是这份，
                                   另含 VOFA 浮点模式，本协议只用 CRC 模式）

对照数据：
  samples/real_frame_000001.bin    真实采集帧，16428 字节，可逐字节比对
  samples/expected.json            该帧的 frame_id / start_index / CRC / 前 16 组样点

自检：
  python tools/check_frame.py <你的输出.bin>
  合格时打印"成功：帧格式完全符合 V32CAP3"，退出码 0。

  先跑这条确认脚本本身正常：
  python tools/check_frame.py samples/real_frame_000001.bin --dump 8

最容易写错的四处（详见规格书 §10）：
  1. 12 位样点必须符号扩展（-13 要发 F3 FF，不是 F3 0F）
  2. CRC 只覆盖前 16424 字节，尾部 4 字节是 ~crc
  3. points_per_channel = 4096，不是 8192
  4. 帧长恒为 16428，多一字节会让下一帧的魔数错位
