`timescale 1ns/1ps
`default_nettype none
// Non-blocking RAW snapshot. Capture N consecutive valid samples per channel,
// then freeze memory throughout export. Fault aborts capture, never truncates export.
// CRC mode: 'V32CAP3!' + eight LE u32 + N LE {s16 CH0,s16 CH1} + LE CRC32.
// Header words: version,frame_id,Fs,decimation,N,flags,start_index_lo,hi.
// VOFA mode: NaN/NaN separator, exactly N two-float rows. CRC mode is recommended
// for training; VOFA mode has no frame-integrity guarantee.
module raw_snapshot_uart #(
 parameter integer POINTS=4096,CLK_FREQ=65000000,BAUD=921600,
 parameter integer PERIOD_CLKS=6500000,FS_HZ=65000000,DECIMATION=1,
 parameter integer CRC_PACKET=1
)(
 input wire clk,rst_n,sample_valid,fault,
 input wire signed [11:0] ch0,ch1,
 output wire tx,output wire busy,
 output reg [31:0] completed,aborted,skipped
);
 localparam AW=$clog2(POINTS);
 localparam IDLE=0,CAP=1,HEADER=2,READ=3,DATA=4,TRAILER=5,SEP=6;
 reg [2:0] state;reg [31:0] timer,frame_id,flags;
 reg [63:0] sample_index,start_index;
 reg [AW-1:0] addr;reg [5:0] pos;
 (* ram_style="block" *) reg [31:0] memory[0:POINTS-1];
 reg [31:0] word_q,crc;
 wire ready;reg [7:0] byte_data;wire sending=state==HEADER || state==DATA || state==TRAILER || state==SEP;
 assign busy=state!=IDLE;
 wire [31:0] packed_sample={{4{ch1[11]}},ch1,{4{ch0[11]}},ch0};
 wire begin_capture=state==IDLE && timer==0 && sample_valid && !fault;
 wire memory_we=begin_capture || (state==CAP && sample_valid && !fault);
 wire [AW-1:0] memory_wr_addr=begin_capture?{AW{1'b0}}:addr;
 always @(posedge clk)begin
  // One physical write port with an address mux, not two inferred write ports.
  if(memory_we)memory[memory_wr_addr]<=packed_sample;
  if(state==READ)word_q<=memory[addr];
 end
 function [31:0] crc_byte;
  input [31:0] c;input [7:0] d;reg [31:0] v;integer k;
  begin v=c^d;for(k=0;k<8;k=k+1)v=v[0]?((v>>1)^32'hedb88320):(v>>1);crc_byte=v;end
 endfunction
 function [31:0] as_float;
  input signed [15:0] x;reg [15:0] mag;integer k,top;reg[7:0] exponent;reg[31:0] norm;
  begin mag=x<0?-x:x;top=0;for(k=0;k<16;k=k+1)if(mag[k])top=k;
   exponent=127+top;norm={16'd0,mag}<<(23-top);
   as_float=mag==0?32'd0:{x[15],exponent,norm[22:0]};end
 endfunction
 reg [31:0] header_word,float_word;
 always @* begin
  case(pos[5:2])
   2:header_word=3;3:header_word=frame_id;4:header_word=FS_HZ;
   5:header_word=DECIMATION;6:header_word=POINTS;7:header_word=flags;
   8:header_word=start_index[31:0];9:header_word=start_index[63:32];default:header_word=0;
  endcase
  float_word=pos<4?as_float($signed(word_q[15:0])):as_float($signed(word_q[31:16]));
  byte_data=0;
  if(state==HEADER) begin
   if(pos<8)case(pos)0:byte_data="V";1:byte_data="3";2:byte_data="2";3:byte_data="C";
    4:byte_data="A";5:byte_data="P";6:byte_data="3";7:byte_data="!";endcase
   else byte_data=header_word>>(8*pos[1:0]);
  end else if(state==DATA)byte_data=CRC_PACKET?(word_q>>(8*pos[1:0])):(float_word>>(8*pos[1:0]));
  else if(state==TRAILER)begin
   if(CRC_PACKET)byte_data=(~crc)>>(8*pos[1:0]);
   else case(pos)0,1:byte_data=0;2:byte_data=8'h80;default:byte_data=8'h7f;endcase
  end else if(state==SEP)begin
   case(pos)2,6:byte_data=8'hc0;3,7:byte_data=8'h7f;10:byte_data=8'h80;11:byte_data=8'h7f;default:byte_data=0;endcase
  end
 end
 uart_tx #(.CLK_FREQ(CLK_FREQ),.BAUD(BAUD)) uart(.clk(clk),.rst_n(rst_n),.tx_data(byte_data),.tx_valid(sending),.tx_ready(ready),.tx(tx));
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;timer<=0;frame_id<=0;flags<=0;sample_index<=0;start_index<=0;
   addr<=0;pos<=0;crc<=32'hffffffff;completed<=0;aborted<=0;skipped<=0;
  end else begin
   sample_index<=sample_index+1'b1; // ADC clock tick; gaps abort the snapshot.
   if(timer!=0)timer<=timer-1'b1;
   if(fault && state>=HEADER)flags<=flags; // Header metadata frozen during export.
   case(state)
    IDLE:if(begin_capture)begin
     addr<=1;start_index<=sample_index;state<=CAP;timer<=PERIOD_CLKS;flags<=0;
    end else if(sample_valid && timer==0 && fault)skipped<=skipped+1'b1;
    CAP:if(fault || !sample_valid)begin
     state<=IDLE;aborted<=aborted+1'b1;timer<=PERIOD_CLKS;
    end else begin
     if(addr==POINTS-1)begin
      frame_id<=frame_id+1'b1;state<=CRC_PACKET?HEADER:SEP;pos<=0;crc<=32'hffffffff;addr<=0;
     end else addr<=addr+1'b1;
    end
    HEADER:if(ready)begin
     crc<=crc_byte(crc,byte_data);
     if(pos==39)begin state<=READ;pos<=0;end else pos<=pos+1'b1;
    end
    SEP:if(ready)begin if(pos==11)begin state<=READ;pos<=0;end else pos<=pos+1'b1;end
    READ:begin state<=DATA;pos<=0;end
    DATA:if(ready)begin
     if(CRC_PACKET)crc<=crc_byte(crc,byte_data);
     if(pos==(CRC_PACKET?3:7))begin state<=TRAILER;pos<=0;
      if(CRC_PACKET && addr!=POINTS-1)begin addr<=addr+1'b1;state<=READ;end
     end else pos<=pos+1'b1;
    end
    TRAILER:if(ready)begin
     if(pos==3)begin
      pos<=0;
      if(CRC_PACKET || addr==POINTS-1)begin state<=IDLE;completed<=completed+1'b1;end
      else begin addr<=addr+1'b1;state<=READ;end
     end else pos<=pos+1'b1;
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
